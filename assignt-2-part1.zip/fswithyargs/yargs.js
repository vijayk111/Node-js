const argv = require('yargs').argv;
const fs = require('fs');
const readline = require('readline');

const rl = readline.createInterface({
    input : process.stdin,
    output : process.stdout
});

const fileContent = fs.readFileSync('filenameList.txt');
var array = new Array();
if(fileContent.length !== 0){
    array = JSON.parse(fileContent);
}

if(argv._[0] == 'write'){
    console.log(array);
    askForUserInput('Please provide the filename: ');
}else{
    console.log('No write operation');
}

function askForUserInput(msg){
    rl.question(msg, (fileName) => {
        if(ifFileExists(fileName)){
            askForUserInput('File already exists, Please provide new filename: ');
        }else{
            writeToFile(fileName);
            rl.close();
        }
    });
}

function ifFileExists(fpath){
    try{
        fs.accessSync(fpath, fs.constants.F_OK);
        return true;
    }catch(e){
        return false;
    }
}

function writeToFile(fileName){
    array.push(fileName);
    console.log('after pushing '+array);
    fs.writeFileSync('filenameList.txt', JSON.stringify(array));
        fs.writeFile(fileName, 'You are Awesome!', err => {
            if(err){
                console.log('Error occured!');
                return;
            }
    });
}
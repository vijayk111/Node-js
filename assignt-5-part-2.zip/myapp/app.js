const express = require("express");
const mongoose = require("mongoose");
const url = 'mongodb://127.0.0.1:27017/';

const order = require('./model/orderModel');

const app = express();
const port = 3300;

const sgMail = require('@sendgrid/mail');
const sendgridAPIKey = '';

sgMail.setApiKey(sendgridAPIKey);

app.set('view-engine', 'ejs');
app.use(express.urlencoded({extended : true}));
app.use(express.json());

try {
    mongoose.connect(url, { useUnifiedTopology: true, useNewUrlParser: true });
    app.listen(3300, function(){});
    console.log("server started at port : 3300");
}catch (error) {
    handleError(error);
}

app.get('/', (req, res) => {
    const orders = order.find(function(err, data){
        if(err){
            res.status(500).send(err);
        }else{            
            data.forEach(ele => {
                if(ele.date.getDate()-new Date().getDate() == 2){
                    ele.status = "Delivered";
                }else if(ele.date.getDate()-new Date().getDate() == 1){
                    ele.status = "Dispatched"
                }else{
                    ele.status = "Progress";
                }
            })
            res.render('index.ejs', {orders : data});
        }
    })
});

app.get('/sendmail',(req, res) => {    
    console.log(req.query);
    sgMail.send({
        to: req.query.email,
        from: 'sendermail@gmail.com',
        subject: 'Delivery status of your order',
        text: 'Order Status : '+req.query.status
    },(err, result) => {
        if(err){
            res.status(500).send(err);
        }else{
            console.log("email sent to "+req.query.email);
            res.redirect('/');
        }
    })
});
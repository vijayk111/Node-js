const express = require('express');
const fs = require('fs');
const fetch = require('node-fetch');

const app = express();
const port = 3500;

app.get('/employee/:id',(req, res)=>{    
    new Promise((resolve, reject) => {
        fs.readFile('first.json',(err, records) => {
            if(err){
                reject(err);
            }else{
                resolve(records);
            }
        })
    }).then((records) => {
        let data = JSON.parse(records);
        data = data.employee.filter((record) => {
            return record.id === parseInt(req.params.id)
        });
        res.send(data);
    }).catch((err) => {
        console.log("error", err);
    });
});

app.get('/project/:id', function(req,res){
    new Promise((resolve, reject) => {
        fs.readFile('second.json', (err, records) => {
            if(err){
                reject(err);
            }else{
                resolve(records);
            }
        })
    }).then((records) => {
        let data = JSON.parse(records);
        data = data.project.filter((record) => {
            return record.id === parseInt(req.params.id)
        });
        res.send(data);
    }).catch((err)=>{
        console.log("error",err);
    });
});

app.get('/getemployeedetails',function(req, res){      
    let employees = [];
    let result = [];
    employees = JSON.parse(fs.readFileSync('first.json')).employee;
    let promises = [];
    for (let employee of employees) {
        promises.push(fetch('http://localhost:3500/project/' + employee.projectId)
        .then((response) => response.json())       
        .then((json) => {
            var obj = Object.assign(json[0], JSON.parse(JSON.stringify(employee)));
            result.push(obj);
        }))
    }
    Promise.all(promises).then(() => res.send(result));
});

app.listen(port, () => {
    console.log(`Example app listening on port ${port}!`)
});
const express = require('express');
const MongoClient = require('mongodb').MongoClient;
const app = express();
const url = 'mongodb://127.0.0.1:27017/';
const col_name = 'bugs';
const moment = require('moment');

app.set('view engine', 'ejs');
app.set('views', './views');
app.use(express.urlencoded({extended : true}));
app.use(express.json());

const client= new MongoClient(url, {
    useNewUrlParser : true,
    useUnifiedTopology : true
});

client.connect((err, database) => {
    if(err){
        throw err;
    }else{
        db = database.db('bugs');
        app.listen(3300, function(){
            console.log("server started at 3300");
        });
    }
})

app.get('/', (req, res) => {
    db.collection(col_name).find().toArray().then( result => {
        res.render('index.ejs', {data : result, moment : moment});
    }).catch(err => {
        throw err;
    });
});

//navigating to addbug page
app.get('/addBugPage', (req, res) => {
    res.render('addbug');
})

app.post('/addBug', (req, res) => {
    const date = new Date();
    req.body.date = date;
    db.collection(col_name).insert(req.body, (err, result) => {
        if(err){
            throw err;
        }else{
            console.log("Row inserted");
            res.redirect('/');
        }
    });
});
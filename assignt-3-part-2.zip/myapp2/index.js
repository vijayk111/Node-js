const express = require('express');
const request = require('request');

const app = express();
const port = 3500;

const urlPath = "http://5c055de56b84ee00137d25a0.mockapi.io/api/v1/employees";

// Static file path
app.use(express.static(__dirname+'/public'));
// Html or rending Path
app.set('views', './views');
// View engine specification
app.set('view engine', 'ejs');


app.get('/',(req, res) => {
    let data = [];
    request(urlPath, {json: true}, (err, resp, body) => {
        if(err){
            console.log("unable to connect to the server");
        }else{
            console.log(body);
            data = body;
            res.render('./index',{result : data, title : "List of Employees"});
        }
    });   
});


app.listen(port ,(err) => {
    if(err) { console.log('error in api call')}
    else{ console.log ('App is running on port '+port)}
})
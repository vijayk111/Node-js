var mongoose = require('mongoose');

var orderModel = new mongoose.Schema({
    name : {type : String},
    address : {type : String},
    email : {type : String},
    item : [String],
    date : {type : Date}
});

module.exports = mongoose.model('order', orderModel, 'orderlist');